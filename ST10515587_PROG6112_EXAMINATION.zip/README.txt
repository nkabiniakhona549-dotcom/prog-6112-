MATTRESS SALES - NETBEANS (ANT) PROJECTS
Q1_SalesReport  : console sales report + unit tests (Question 1)
Q2_SalesApp     : Swing GUI sales app (Question 2)

Open in NetBeans: File > Open Project > select each folder. NetBeans generates nbproject/build-impl.xml on first open.
Run: right-click the project > Run. Tests: right-click the project > Test.
Unit tests use the JUnit 5 library. If NetBeans reports it missing, right-click the project > Properties >
Libraries > Test Libraries > Add Library > JUnit 5.
