package mattress;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class DataFileWriter {

    private static final String LINE = "********************************************";

    private final File file;

    public DataFileWriter(String fileName) {
        this.file = new File(fileName);
    }

    /** Appends a record to the file, writing the DATA LOG heading when the file is new or empty. */
    public void save(SaleRecord record) throws IOException {
        boolean newFile = !file.exists() || file.length() == 0;
        try (PrintWriter out = new PrintWriter(new FileWriter(file, true))) {
            if (newFile) {
                out.println("DATA LOG");
            }
            out.println(LINE);
            out.println(record.toDetailText());
            out.println(LINE);
        }
    }
}
