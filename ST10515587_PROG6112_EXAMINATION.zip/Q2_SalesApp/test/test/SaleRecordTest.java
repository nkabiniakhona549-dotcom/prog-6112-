package test;

import mattress.SaleRecord;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class SaleRecordTest {

    @Test
    void DetailText_WithValidRecord_MatchesSampleLayout() {
        SaleRecord r = new SaleRecord("Joe Bloggs", "Cozy Nights Monarch", 3500);
        String expected = "Customer Name: Joe Bloggs\nProduct: Cozy Nights Monarch\n"
                + "VAT: R 525.0\nCOMMISSION: R 175.0\nTOTAL: R 4200.0";
        assertEquals(expected, r.toDetailText());
    }
}
