package mattress;

/**
 * Holds the sales data for the top products.
 * productNames: single-dimensional array (one entry per product)
 * sales:        two-dimensional array [product][month]
 */
public class Product implements IProduct {

    private final String[] productNames;
    private final int[][] sales;

    public Product(String[] productNames, int[][] sales) {
        if (productNames == null || sales == null || productNames.length != sales.length) {
            throw new IllegalArgumentException("Each product must have a row of sales data.");
        }
        this.productNames = productNames;
        this.sales = sales;
    }

    /** Total units sold for one product across all months. */
    public int GetProductTotal(int productIndex) {
        int total = 0;
        for (int units : sales[productIndex]) {
            total += units;
        }
        return total;
    }

    @Override
    public int GetTotalProductsSold() {
        int total = 0;
        for (int i = 0; i < sales.length; i++) {
            total += GetProductTotal(i);
        }
        return total;
    }

    /** Average units sold per product per month (total / number of sales entries). */
    @Override
    public double GetAverageProductSold() {
        int entries = 0;
        for (int[] row : sales) {
            entries += row.length;
        }
        return entries == 0 ? 0 : (double) GetTotalProductsSold() / entries;
    }

    @Override
    public String GetMostPopularProduct() {
        int best = 0;
        for (int i = 1; i < sales.length; i++) {
            if (GetProductTotal(i) > GetProductTotal(best)) {
                best = i;
            }
        }
        return productNames[best];
    }

    /** Total units sold of the most popular product. */
    public int GetMostPopularProductTotal() {
        int best = 0;
        for (int i = 1; i < sales.length; i++) {
            if (GetProductTotal(i) > GetProductTotal(best)) {
                best = i;
            }
        }
        return GetProductTotal(best);
    }
}
