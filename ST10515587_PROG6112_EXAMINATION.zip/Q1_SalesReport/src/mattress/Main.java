package mattress;

import java.time.Year;
import java.util.Scanner;

public class Main {

    private static final int MONTHS = 3;

    public static void main(String[] args) {
        String[] names = {"Cozy Nights Monarch", "Restonic Barbados", "Sealy Phuket"};
        int[][] sales = new int[names.length][MONTHS];

        Scanner input = new Scanner(System.in);
        for (int p = 0; p < names.length; p++) {
            for (int m = 0; m < MONTHS; m++) {
                sales[p][m] = readNonNegativeInt(input,
                        "Enter number of sales for month " + (m + 1) + " for " + names[p] + " mattress: ");
            }
            System.out.println();
        }

        Product product = new Product(names, sales);
        PrintProduct printer = new PrintProduct(product);
        printer.PrintHeader(Year.now().getValue());
        printer.PrintTotalProductSales();
        printer.PrintAverageProductSales();
        printer.PrintMostPopularProduct();
    }

    private static int readNonNegativeInt(Scanner input, String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = input.nextLine().trim();
            try {
                int value = Integer.parseInt(line);
                if (value >= 0) {
                    return value;
                }
            } catch (NumberFormatException ignored) {
                // fall through to the message below
            }
            System.out.println("Please enter a whole number of 0 or more.");
        }
    }
}
