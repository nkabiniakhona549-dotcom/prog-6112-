package mattress;

import java.text.DecimalFormat;

public class PrintProduct {

    private final Product product;
    private final DecimalFormat format = new DecimalFormat("0.##");

    public PrintProduct(Product product) {
        this.product = product;
    }

    public void PrintHeader(int year) {
        System.out.println();
        System.out.println("PRODUCT SALES REPORT - " + year);
        System.out.println();
        System.out.println("********************************************");
    }

    public void PrintTotalProductSales() {
        System.out.println("TOTAL PRODUCT SALES: " + product.GetTotalProductsSold());
    }

    public void PrintAverageProductSales() {
        System.out.println("AVERAGE PRODUCT SALES: " + format.format(product.GetAverageProductSold()));
    }

    public void PrintMostPopularProduct() {
        System.out.println("MOST POPULAR PRODUCT: " + product.GetMostPopularProduct()
                + " (" + product.GetMostPopularProductTotal() + ")");
    }
}
