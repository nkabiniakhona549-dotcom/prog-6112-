package mattress;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;

public class ProductApp extends JFrame {

    private static final String[] PRODUCTS = {"Cozy Nights Monarch", "Restonic Barbados", "Sealy Phuket"};
    private static final String DATA_FILE = "data.txt";

    private final JTextField txtCustomer = new JTextField(18);
    private final JComboBox<String> cboProduct = new JComboBox<>(PRODUCTS);
    private final JTextField txtPrice = new JTextField(18);
    private final JButton btnProcess = new JButton("PROCESS");
    private final DataFileWriter writer = new DataFileWriter(DATA_FILE);

    public ProductApp() {
        super("Product App");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setJMenuBar(buildMenuBar());

        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(6, 6, 6, 6);
        c.anchor = GridBagConstraints.WEST;

        addRow(form, c, 0, "Customer Name:", txtCustomer);
        addRow(form, c, 1, "Select Product:", cboProduct);
        addRow(form, c, 2, "Enter Price:", txtPrice);

        c.gridx = 0; c.gridy = 3; c.gridwidth = 2; c.anchor = GridBagConstraints.CENTER;
        form.add(btnProcess, c);

        btnProcess.addActionListener(e -> processSale());
        getRootPane().setDefaultButton(btnProcess);

        add(form);
        pack();
        setLocationRelativeTo(null);
    }

    private void addRow(JPanel p, GridBagConstraints c, int row, String label, JComponent field) {
        c.gridy = row; c.gridwidth = 1;
        c.gridx = 0; p.add(new JLabel(label), c);
        c.gridx = 1; p.add(field, c);
    }

    private JMenuBar buildMenuBar() {
        JMenuBar bar = new JMenuBar();
        JMenu file = new JMenu("File");
        JMenuItem exit = new JMenuItem("Exit");
        exit.addActionListener(e -> System.exit(0));
        file.add(exit);

        JMenu edit = new JMenu("Edit");
        JMenuItem clear = new JMenuItem("Clear");
        clear.addActionListener(e -> clearForm());
        edit.add(clear);

        bar.add(file);
        bar.add(edit);
        return bar;
    }

    private void processSale() {
        String customer = txtCustomer.getText().trim();
        if (customer.isEmpty()) {
            error("Please enter the customer name.");
            return;
        }

        double price;
        try {
            price = Double.parseDouble(txtPrice.getText().trim());
        } catch (NumberFormatException ex) {
            error("Please enter a valid price, for example 3500.");
            return;
        }
        if (price <= 0) {
            error("The price must be greater than zero.");
            return;
        }

        SaleRecord record = new SaleRecord(customer, (String) cboProduct.getSelectedItem(), price);

        try {
            writer.save(record);
        } catch (IOException ex) {
            error("The sale could not be saved to " + DATA_FILE + ": " + ex.getMessage());
            return;
        }

        JOptionPane.showMessageDialog(this, record.toDetailText(), "Message", JOptionPane.INFORMATION_MESSAGE);
    }

    private void clearForm() {
        txtCustomer.setText("");
        txtPrice.setText("");
        cboProduct.setSelectedIndex(0);
        txtCustomer.requestFocus();
    }

    private void error(String message) {
        JOptionPane.showMessageDialog(this, message, "Input error", JOptionPane.ERROR_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ProductApp().setVisible(true));
    }
}
