package mattress;

public class SaleRecord {

    private final String customerName;
    private final String productName;
    private final double vat;
    private final double commission;
    private final double total;

    public SaleRecord(String customerName, String productName, double price) {
        SaleCalculator calc = new SaleCalculator(price);
        this.customerName = customerName;
        this.productName = productName;
        this.vat = calc.getVat();
        this.commission = calc.getCommission();
        this.total = calc.getTotal();
    }

    public String getCustomerName() { return customerName; }
    public String getProductName() { return productName; }
    public double getVat() { return vat; }
    public double getCommission() { return commission; }
    public double getTotal() { return total; }

    /** Text shown in the message dialog and written inside the data file. */
    public String toDetailText() {
        return "Customer Name: " + customerName + "\n"
             + "Product: " + productName + "\n"
             + "VAT: R " + vat + "\n"
             + "COMMISSION: R " + commission + "\n"
             + "TOTAL: R " + total;
    }
}
