package mattress;

/** Business rules: VAT 15%, commission 5%, total = price + VAT + commission. */
public class SaleCalculator {

    public static final double VAT_RATE = 0.15;
    public static final double COMMISSION_RATE = 0.05;

    private final double price;

    public SaleCalculator(double price) {
        this.price = price;
    }

    public double getVat() {
        return round(price * VAT_RATE);
    }

    public double getCommission() {
        return round(price * COMMISSION_RATE);
    }

    public double getTotal() {
        return round(price + getVat() + getCommission());
    }

    private static double round(double value) {
        return Math.round(value * 100.0) / 100.0;
    }
}
