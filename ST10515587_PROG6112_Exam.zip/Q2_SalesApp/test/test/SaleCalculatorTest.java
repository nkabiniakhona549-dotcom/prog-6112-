package test;

import mattress.SaleCalculator;
import mattress.SaleRecord;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class SaleCalculatorTest {

    @Test
    void Calculations_WithValidPrice_ReturnCorrectValues() {
        SaleCalculator calc = new SaleCalculator(3500);
        assertEquals(525.0, calc.getVat(), 0.001);
        assertEquals(175.0, calc.getCommission(), 0.001);
        assertEquals(4200.0, calc.getTotal(), 0.001);
    }

    @Test
    void DetailText_WithValidRecord_MatchesSampleLayout() {
        SaleRecord r = new SaleRecord("Joe Bloggs", "Cozy Nights Monarch", 3500);
        String expected = "Customer Name: Joe Bloggs\nProduct: Cozy Nights Monarch\n"
                + "VAT: R 525.0\nCOMMISSION: R 175.0\nTOTAL: R 4200.0";
        assertEquals(expected, r.toDetailText());
    }
}
