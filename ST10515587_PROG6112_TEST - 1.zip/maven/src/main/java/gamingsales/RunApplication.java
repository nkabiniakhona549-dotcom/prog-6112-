package gamingsales;

import java.util.Scanner;

/**
 * Question 2 - console application that lets the user select a console type,
 * enter a store name and total sales, then prints the report.
 */
public class RunApplication {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String[] consoleTypes = {"PS5", "XBOX", "SWITCH"};

        System.out.println("Select the console type");
        for (int i = 0; i < consoleTypes.length; i++) {
            System.out.println((i + 1) + ") " + consoleTypes[i]);
        }
        System.out.println();

        int choice = 0;
        while (choice < 1 || choice > consoleTypes.length) {
            if (input.hasNextInt()) {
                choice = input.nextInt();
            } else {
                input.next();
            }
            if (choice < 1 || choice > consoleTypes.length) {
                System.out.println("Invalid choice, please enter 1, 2 or 3:");
                choice = 0;
            }
        }
        input.nextLine(); // clear the newline left by nextInt()
        String consoleType = consoleTypes[choice - 1];

        String store = "";
        while (store.trim().isEmpty()) {
            System.out.print("Enter the store: ");
            store = input.nextLine().trim();
        }

        int totalSales = -1;
        while (totalSales < 0) {
            System.out.print("Enter the total sales of " + consoleType
                    + " consoles for " + store + ":");
            if (input.hasNextInt()) {
                totalSales = input.nextInt();
                if (totalSales < 0) {
                    System.out.println("Sales cannot be negative.");
                }
            } else {
                System.out.println("Please enter a whole number.");
                input.next();
            }
        }

        Consoles sale = new ConsoleSales(consoleType, store, totalSales);
        System.out.println();
        sale.printReport();
        input.close();
    }
}
