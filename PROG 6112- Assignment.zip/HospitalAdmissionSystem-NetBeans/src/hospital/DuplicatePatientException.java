package hospital;

/** Thrown when attempting to register a patient with an ID that already exists. */
public class DuplicatePatientException extends Exception {
    private static final long serialVersionUID = 1L;

    public DuplicatePatientException(String message) {
        super(message);
    }
}
