package hospital;

/**
 * Inpatient extends Patient (inheritance) and adds ward/bed information,
 * since only Inpatients are allocated a hospital bed.
 */
public class Inpatient extends Patient {

    private String wardNumber;
    private String bedNumber;

    public Inpatient(String patientId, String firstName, String lastName, int age,
                      String gender, String medicalCondition,
                      String wardNumber, String bedNumber) {
        // super() is used to initialise the inherited attributes from Patient.
        super(patientId, firstName, lastName, age, gender, medicalCondition, PatientCategory.INPATIENT);
        this.wardNumber = wardNumber;
        this.bedNumber = bedNumber;
    }

    public String getWardNumber() {
        return wardNumber;
    }

    public void setWardNumber(String wardNumber) {
        this.wardNumber = wardNumber;
    }

    public String getBedNumber() {
        return bedNumber;
    }

    public void setBedNumber(String bedNumber) {
        this.bedNumber = bedNumber;
    }

    /**
     * Overrides the superclass method to include ward and bed information,
     * demonstrating method overriding / polymorphism.
     */
    @Override
    public void displayDetails() {
        super.displayDetails();
        System.out.println("Ward Number    : " + wardNumber);
        System.out.println("Bed Number     : " + bedNumber);
    }
}
