package hospital;

/**
 * Base class representing a hospital patient.
 * Outpatients and Emergency patients use this class directly (as per the
 * assignment brief), while Inpatients use the Inpatient subclass which adds
 * ward/bed information.
 *
 * Fields are declared private to apply information hiding / encapsulation,
 * and are only accessible through the public getters and setters.
 */
public class Patient {

    private String patientId;
    private String firstName;
    private String lastName;
    private int age;
    private String gender;
    private String medicalCondition;
    private PatientCategory category;

    public Patient(String patientId, String firstName, String lastName, int age,
                   String gender, String medicalCondition, PatientCategory category) {
        if (age < 0) {
            throw new IllegalArgumentException("Age cannot be negative.");
        }
        this.patientId = patientId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
        this.gender = gender;
        this.medicalCondition = medicalCondition;
        this.category = category;
    }

    // ---------- Getters and Setters (encapsulation) ----------

    public String getPatientId() {
        return patientId;
    }

    public void setPatientId(String patientId) {
        this.patientId = patientId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        if (age < 0) {
            throw new IllegalArgumentException("Age cannot be negative.");
        }
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getMedicalCondition() {
        return medicalCondition;
    }

    public void setMedicalCondition(String medicalCondition) {
        this.medicalCondition = medicalCondition;
    }

    public PatientCategory getCategory() {
        return category;
    }

    public void setCategory(PatientCategory category) {
        this.category = category;
    }

    /**
     * Displays the patient's details to the console.
     * This method is overridden by Inpatient to add ward/bed information
     * (polymorphism / method overriding).
     */
    public void displayDetails() {
        System.out.println("-----------------------------------");
        System.out.println("Patient ID     : " + patientId);
        System.out.println("Name           : " + firstName + " " + lastName);
        System.out.println("Age            : " + age);
        System.out.println("Gender         : " + gender);
        System.out.println("Condition      : " + medicalCondition);
        System.out.println("Category       : " + category.getDisplayName());
    }

    @Override
    public String toString() {
        return patientId + " - " + firstName + " " + lastName + " (" + category.getDisplayName() + ")";
    }
}
