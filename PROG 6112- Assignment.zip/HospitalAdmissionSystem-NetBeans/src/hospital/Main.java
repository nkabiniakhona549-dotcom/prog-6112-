package hospital;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * Console-based, menu-driven entry point for the MediCare Hospital
 * Patient Admission System.
 */
public class Main {

    private static final Scanner scanner = new Scanner(System.in);
    private static final HospitalService service = new HospitalService();

    public static void main(String[] args) {
        boolean running = true;
        while (running) {
            printMainMenu();
            int choice = readInt("Enter your choice: ");
            switch (choice) {
                case 1:
                    patientManagementMenu();
                    break;
                case 2:
                    bedManagementMenu();
                    break;
                case 3:
                    reportsMenu();
                    break;
                case 0:
                    running = false;
                    System.out.println("Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
        scanner.close();
    }

    // ==================== MAIN MENU ====================

    private static void printMainMenu() {
        System.out.println("\n===== MediCare Hospital Patient Admission System =====");
        System.out.println("1. Patient Management");
        System.out.println("2. Bed Management");
        System.out.println("3. Reports");
        System.out.println("0. Exit");
    }

    // ==================== FEATURE 1: PATIENT MANAGEMENT ====================

    private static void patientManagementMenu() {
        boolean back = false;
        while (!back) {
            System.out.println("\n--- Patient Management ---");
            System.out.println("1. Register a new patient");
            System.out.println("2. Search for a patient");
            System.out.println("3. Update patient details");
            System.out.println("4. Delete a patient");
            System.out.println("5. Display all patients");
            System.out.println("0. Back to main menu");
            int choice = readInt("Enter your choice: ");

            switch (choice) {
                case 1:
                    registerPatient();
                    break;
                case 2:
                    searchPatient();
                    break;
                case 3:
                    updatePatient();
                    break;
                case 4:
                    deletePatient();
                    break;
                case 5:
                    displayAllPatients();
                    break;
                case 0:
                    back = true;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void registerPatient() {
        System.out.println("\n-- Register New Patient --");
        String id = readNonEmptyString("Patient ID: ");
        String firstName = readNonEmptyString("First Name: ");
        String lastName = readNonEmptyString("Last Name: ");
        int age = readNonNegativeInt("Age: ");
        String gender = readNonEmptyString("Gender: ");
        String condition = readNonEmptyString("Medical Condition: ");
        PatientCategory category = readCategory();

        try {
            Patient patient;
            if (category == PatientCategory.INPATIENT) {
                // Ward/bed number left blank until a bed is allocated.
                patient = new Inpatient(id, firstName, lastName, age, gender, condition, "Ward 1", "Not allocated");
            } else {
                patient = new Patient(id, firstName, lastName, age, gender, condition, category);
            }
            service.registerPatient(patient);
            System.out.println("Patient registered successfully.");
        } catch (DuplicatePatientException | IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void searchPatient() {
        String id = readString("Enter Patient ID to search: ");
        try {
            Patient p = service.searchPatient(id);
            p.displayDetails();
        } catch (PatientNotFoundException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void updatePatient() {
        String id = readString("Enter Patient ID to update: ");
        try {
            Patient existing = service.searchPatient(id);
            System.out.println("Leave a field blank to keep the current value.");

            String firstName = readOptionalString("First Name [" + existing.getFirstName() + "]: ", existing.getFirstName());
            String lastName = readOptionalString("Last Name [" + existing.getLastName() + "]: ", existing.getLastName());
            int age = readOptionalInt("Age [" + existing.getAge() + "]: ", existing.getAge());
            String gender = readOptionalString("Gender [" + existing.getGender() + "]: ", existing.getGender());
            String condition = readOptionalString("Medical Condition [" + existing.getMedicalCondition() + "]: ", existing.getMedicalCondition());

            service.updatePatient(id, firstName, lastName, age, gender, condition);
            System.out.println("Patient updated successfully.");
        } catch (PatientNotFoundException | IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void deletePatient() {
        String id = readString("Enter Patient ID to delete: ");
        try {
            service.deletePatient(id);
            System.out.println("Patient deleted successfully.");
        } catch (PatientNotFoundException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void displayAllPatients() {
        ArrayList<Patient> patients = service.getAllPatients();
        if (patients.isEmpty()) {
            System.out.println("No patients registered.");
            return;
        }

        String sortChoice = readString("Sort by (S)urname, (I)D, or (N)one? ");
        if (sortChoice.equalsIgnoreCase("S")) {
            service.sortPatientsBySurname();
        } else if (sortChoice.equalsIgnoreCase("I")) {
            service.sortPatientsById();
        }

        System.out.println("\n=== All Registered Patients (" + patients.size() + ") ===");
        for (Patient p : patients) {
            p.displayDetails();
        }
    }

    // ==================== FEATURE 2: BED MANAGEMENT ====================

    private static void bedManagementMenu() {
        boolean back = false;
        while (!back) {
            System.out.println("\n--- Bed Management ---");
            System.out.println("1. Allocate a bed to an inpatient");
            System.out.println("2. Release a bed");
            System.out.println("3. Display complete ward layout");
            System.out.println("4. Display available beds");
            System.out.println("5. Display occupied beds");
            System.out.println("0. Back to main menu");
            int choice = readInt("Enter your choice: ");

            switch (choice) {
                case 1:
                    allocateBed();
                    break;
                case 2:
                    releaseBed();
                    break;
                case 3:
                    service.getWard().displayWardLayout();
                    break;
                case 4:
                    displayAvailableBeds();
                    break;
                case 5:
                    displayOccupiedBeds();
                    break;
                case 0:
                    back = true;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void allocateBed() {
        String id = readString("Enter Patient ID to allocate a bed to: ");
        try {
            Bed bed = service.allocateBed(id);
            System.out.println("Bed " + bed.getBedNumber() + " allocated to patient " + id + ".");
        } catch (PatientNotFoundException | BedNotAvailableException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void releaseBed() {
        String bedNumber = readString("Enter Bed Number to release (e.g. B01): ");
        try {
            service.releaseBed(bedNumber);
            System.out.println("Bed " + bedNumber + " released successfully.");
        } catch (BedNotAvailableException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void displayAvailableBeds() {
        System.out.println("\n=== Available Beds ===");
        for (Bed b : service.getWard().getAvailableBeds()) {
            System.out.println(b);
        }
    }

    private static void displayOccupiedBeds() {
        System.out.println("\n=== Occupied Beds ===");
        for (Bed b : service.getWard().getOccupiedBeds()) {
            System.out.println(b);
        }
    }

    // ==================== FEATURE 3: REPORTS ====================

    private static void reportsMenu() {
        boolean back = false;
        while (!back) {
            System.out.println("\n--- Reports ---");
            System.out.println("1. Display all registered patients");
            System.out.println("2. Display all available beds");
            System.out.println("3. Display all occupied beds");
            System.out.println("4. Display total number of registered patients and beds");
            System.out.println("0. Back to main menu");
            int choice = readInt("Enter your choice: ");

            switch (choice) {
                case 1:
                    displayAllPatients();
                    break;
                case 2:
                    displayAvailableBeds();
                    break;
                case 3:
                    displayOccupiedBeds();
                    break;
                case 4:
                    System.out.println("\n=== Summary Report ===");
                    System.out.println("Total registered patients : " + service.getTotalRegisteredPatients());
                    System.out.println("Total beds in ward        : " + Ward.TOTAL_BEDS);
                    System.out.println("Total available beds      : " + service.getTotalAvailableBeds());
                    System.out.println("Total occupied beds       : " + service.getTotalOccupiedBeds());
                    break;
                case 0:
                    back = true;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    // ==================== INPUT HELPERS ====================

    private static PatientCategory readCategory() {
        while (true) {
            System.out.println("Patient Category: 1. Inpatient  2. Outpatient  3. Emergency");
            int choice = readInt("Choose category: ");
            switch (choice) {
                case 1:
                    return PatientCategory.INPATIENT;
                case 2:
                    return PatientCategory.OUTPATIENT;
                case 3:
                    return PatientCategory.EMERGENCY;
                default:
                    System.out.println("Invalid choice, please select 1, 2 or 3.");
            }
        }
    }

    private static String readString(String prompt) {
        System.out.print(prompt);
        return scanner.nextLine().trim();
    }

    /** Keeps prompting until the user enters a non-blank value. */
    private static String readNonEmptyString(String prompt) {
        while (true) {
            String value = readString(prompt);
            if (!value.isEmpty()) {
                return value;
            }
            System.out.println("This field cannot be blank. Please try again.");
        }
    }

    /** Keeps prompting until the user enters a whole number that is 0 or greater. */
    private static int readNonNegativeInt(String prompt) {
        while (true) {
            int value = readInt(prompt);
            if (value >= 0) {
                return value;
            }
            System.out.println("Please enter a number that is 0 or greater.");
        }
    }

    private static String readOptionalString(String prompt, String currentValue) {
        System.out.print(prompt);
        String input = scanner.nextLine().trim();
        return input.isEmpty() ? currentValue : input;
    }

    private static int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            try {
                return Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid whole number.");
            }
        }
    }

    private static int readOptionalInt(String prompt, int currentValue) {
        System.out.print(prompt);
        String input = scanner.nextLine().trim();
        if (input.isEmpty()) {
            return currentValue;
        }
        try {
            return Integer.parseInt(input);
        } catch (NumberFormatException e) {
            System.out.println("Invalid number, keeping current value.");
            return currentValue;
        }
    }
}
