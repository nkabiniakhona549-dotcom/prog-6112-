package hospital;

/**
 * Represents a single hospital bed in the ward.
 */
public class Bed {

    private String bedNumber;   // e.g. "B01"
    private boolean occupied;
    private String patientId;   // ID of the patient currently occupying the bed (null if free)

    public Bed(String bedNumber) {
        this.bedNumber = bedNumber;
        this.occupied = false;
        this.patientId = null;
    }

    public String getBedNumber() {
        return bedNumber;
    }

    public boolean isOccupied() {
        return occupied;
    }

    public String getPatientId() {
        return patientId;
    }

    public void occupy(String patientId) {
        this.occupied = true;
        this.patientId = patientId;
    }

    public void release() {
        this.occupied = false;
        this.patientId = null;
    }

    @Override
    public String toString() {
        return occupied ? bedNumber + " [Occupied - " + patientId + "]" : bedNumber + " [Available]";
    }
}
