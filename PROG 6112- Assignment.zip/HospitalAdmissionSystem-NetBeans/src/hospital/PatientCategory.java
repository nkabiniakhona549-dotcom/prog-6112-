package hospital;

/**
 * Enum representing the three categories of patients treated by the hospital.
 * Using an enum here satisfies the "Apply Enum methods" learning outcome and
 * gives us a fixed, type-safe set of categories instead of using raw Strings.
 */
public enum PatientCategory {
    INPATIENT,
    OUTPATIENT,
    EMERGENCY;

    /**
     * Friendly display name used in menus/reports instead of the raw
     * enum constant (e.g. "Inpatient" instead of "INPATIENT").
     */
    public String getDisplayName() {
        switch (this) {
            case INPATIENT:
                return "Inpatient";
            case OUTPATIENT:
                return "Outpatient";
            case EMERGENCY:
                return "Emergency";
            default:
                return this.name();
        }
    }
}
