package hospital;

/** Thrown when trying to allocate a bed that is occupied, invalid, or when the ward is full. */
public class BedNotAvailableException extends Exception {
    private static final long serialVersionUID = 1L;

    public BedNotAvailableException(String message) {
        super(message);
    }
}
