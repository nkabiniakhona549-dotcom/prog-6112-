package hospital;

import java.util.ArrayList;

/**
 * Core service class that manages patients and the ward.
 * Holds all the business logic so it can be reused by both the console Main
 * class and the JUnit tests, without depending on System.in/System.out.
 */
public class HospitalService {

    // Using the ArrayList class to store patients -> satisfies "Using the Array List Class"
    private ArrayList<Patient> patients;
    private Ward ward;

    public HospitalService() {
        this.patients = new ArrayList<>();
        this.ward = new Ward();
    }

    public Ward getWard() {
        return ward;
    }

    public ArrayList<Patient> getPatients() {
        return patients;
    }

    // ---------------- Feature 1: Patient Management ----------------

    public void registerPatient(Patient patient) throws DuplicatePatientException {
        if (patient.getPatientId() == null || patient.getPatientId().trim().isEmpty()) {
            throw new IllegalArgumentException("Patient ID cannot be empty.");
        }
        if (findPatientById(patient.getPatientId()) != null) {
            throw new DuplicatePatientException(
                    "A patient with ID " + patient.getPatientId() + " already exists.");
        }
        // Guard against an inconsistent state where a patient is marked as
        // INPATIENT but was not built as an Inpatient object (and therefore
        // has nowhere to store ward/bed information once a bed is allocated).
        if (patient.getCategory() == PatientCategory.INPATIENT && !(patient instanceof Inpatient)) {
            throw new IllegalArgumentException(
                    "Patients categorised as INPATIENT must be created as Inpatient objects.");
        }
        patients.add(patient);
    }

    /** Linear search for a patient by ID (satisfies "Sorting Arrays"/search learning outcome). */
    public Patient findPatientById(String patientId) {
        for (Patient p : patients) {
            if (p.getPatientId().equalsIgnoreCase(patientId)) {
                return p;
            }
        }
        return null;
    }

    public Patient searchPatient(String patientId) throws PatientNotFoundException {
        Patient p = findPatientById(patientId);
        if (p == null) {
            throw new PatientNotFoundException("No patient found with ID " + patientId);
        }
        return p;
    }

    public void updatePatient(String patientId, String firstName, String lastName, int age,
                               String gender, String medicalCondition) throws PatientNotFoundException {
        if (age < 0) {
            throw new IllegalArgumentException("Age cannot be negative.");
        }
        Patient p = searchPatient(patientId);
        p.setFirstName(firstName);
        p.setLastName(lastName);
        p.setAge(age);
        p.setGender(gender);
        p.setMedicalCondition(medicalCondition);
    }

    /**
     * Deletes a patient. If the patient is an Inpatient occupying a bed,
     * the bed is automatically released first.
     */
    public void deletePatient(String patientId) throws PatientNotFoundException {
        Patient p = searchPatient(patientId);
        Bed bed = ward.findBedByPatientId(patientId);
        if (bed != null) {
            bed.release();
        }
        patients.remove(p);
    }

    public ArrayList<Patient> getAllPatients() {
        return patients;
    }

    // ---------------- Feature 2: Bed Management ----------------

    public Bed allocateBed(String patientId) throws PatientNotFoundException, BedNotAvailableException {
        Patient p = searchPatient(patientId);

        if (p.getCategory() != PatientCategory.INPATIENT) {
            throw new BedNotAvailableException(
                    "Only Inpatients may be allocated a hospital bed. Patient " + patientId
                            + " is categorised as " + p.getCategory().getDisplayName() + ".");
        }
        if (ward.findBedByPatientId(patientId) != null) {
            throw new BedNotAvailableException("Patient " + patientId + " is already allocated a bed.");
        }
        Bed bed = ward.findAvailableBed();
        if (bed == null) {
            throw new BedNotAvailableException("No beds are available. The ward is full.");
        }
        bed.occupy(patientId);

        if (p instanceof Inpatient) {
            Inpatient inpatient = (Inpatient) p;
            inpatient.setWardNumber("Ward 1");
            inpatient.setBedNumber(bed.getBedNumber());
        }
        return bed;
    }

    public void releaseBed(String bedNumber) throws BedNotAvailableException {
        Bed bed = ward.findBed(bedNumber);
        if (bed == null) {
            throw new BedNotAvailableException("Bed " + bedNumber + " does not exist.");
        }
        if (!bed.isOccupied()) {
            throw new BedNotAvailableException("Bed " + bedNumber + " is already available.");
        }

        String patientId = bed.getPatientId();
        Patient p = findPatientById(patientId);
        if (p instanceof Inpatient) {
            // Use "Not allocated" rather than null so displayDetails() never
            // prints the literal text "null" for a released patient.
            ((Inpatient) p).setBedNumber("Not allocated");
        }
        bed.release();
    }

    // ---------------- Feature 3: Reports ----------------

    public int getTotalRegisteredPatients() {
        return patients.size();
    }

    public int getTotalAvailableBeds() {
        return ward.getAvailableBeds().size();
    }

    public int getTotalOccupiedBeds() {
        return ward.getOccupiedBeds().size();
    }

    // ---------------- Sorting (bubble sort) ----------------

    /**
     * Sorts the patients list by surname using the Bubble Sort algorithm,
     * as required by the "Sorting Arrays" learning outcome.
     */
    public void sortPatientsBySurname() {
        int n = patients.size();
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - 1 - i; j++) {
                Patient a = patients.get(j);
                Patient b = patients.get(j + 1);
                if (a.getLastName().compareToIgnoreCase(b.getLastName()) > 0) {
                    patients.set(j, b);
                    patients.set(j + 1, a);
                }
            }
        }
    }

    /** Sorts the patients list by Patient ID using the Bubble Sort algorithm. */
    public void sortPatientsById() {
        int n = patients.size();
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - 1 - i; j++) {
                Patient a = patients.get(j);
                Patient b = patients.get(j + 1);
                if (a.getPatientId().compareToIgnoreCase(b.getPatientId()) > 0) {
                    patients.set(j, b);
                    patients.set(j + 1, a);
                }
            }
        }
    }
}
