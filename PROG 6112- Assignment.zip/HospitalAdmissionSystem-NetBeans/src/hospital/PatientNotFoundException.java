package hospital;

/** Thrown when a requested Patient ID cannot be found in the system. */
public class PatientNotFoundException extends Exception {
    private static final long serialVersionUID = 1L;

    public PatientNotFoundException(String message) {
        super(message);
    }
}
