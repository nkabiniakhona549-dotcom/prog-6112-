package hospital;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents the hospital ward, which contains 20 beds arranged in a
 * 4 x 5 layout (a two-dimensional array), as required by the brief.
 */
public class Ward {

    public static final int ROWS = 4;
    public static final int COLS = 5;
    public static final int TOTAL_BEDS = ROWS * COLS;

    // Two-dimensional array of beds -> satisfies "Using two-dimensional arrays"
    private Bed[][] beds;

    public Ward() {
        beds = new Bed[ROWS][COLS];
        int bedCount = 1;
        for (int row = 0; row < ROWS; row++) {
            for (int col = 0; col < COLS; col++) {
                String bedNumber = String.format("B%02d", bedCount);
                beds[row][col] = new Bed(bedNumber);
                bedCount++;
            }
        }
    }

    /** Returns the flattened list of all beds (helper for searching). */
    public List<Bed> getAllBeds() {
        List<Bed> all = new ArrayList<>();
        for (int row = 0; row < ROWS; row++) {
            for (int col = 0; col < COLS; col++) {
                all.add(beds[row][col]);
            }
        }
        return all;
    }

    /** Finds a bed by its bed number, or null if not found. */
    public Bed findBed(String bedNumber) {
        for (Bed bed : getAllBeds()) {
            if (bed.getBedNumber().equalsIgnoreCase(bedNumber)) {
                return bed;
            }
        }
        return null;
    }

    /** Finds the first available (unoccupied) bed, or null if the ward is full. */
    public Bed findAvailableBed() {
        for (Bed bed : getAllBeds()) {
            if (!bed.isOccupied()) {
                return bed;
            }
        }
        return null;
    }

    /** Finds the bed currently occupied by the given patient ID, or null. */
    public Bed findBedByPatientId(String patientId) {
        for (Bed bed : getAllBeds()) {
            if (bed.isOccupied() && bed.getPatientId().equals(patientId)) {
                return bed;
            }
        }
        return null;
    }

    public boolean hasAvailableBed() {
        return findAvailableBed() != null;
    }

    public List<Bed> getAvailableBeds() {
        List<Bed> available = new ArrayList<>();
        for (Bed bed : getAllBeds()) {
            if (!bed.isOccupied()) {
                available.add(bed);
            }
        }
        return available;
    }

    public List<Bed> getOccupiedBeds() {
        List<Bed> occupied = new ArrayList<>();
        for (Bed bed : getAllBeds()) {
            if (bed.isOccupied()) {
                occupied.add(bed);
            }
        }
        return occupied;
    }

    /** Displays the complete 4x5 ward layout using nested loops. */
    public void displayWardLayout() {
        System.out.println("\n=== Ward Layout (4 x 5) ===");
        for (int row = 0; row < ROWS; row++) {
            StringBuilder line = new StringBuilder();
            for (int col = 0; col < COLS; col++) {
                Bed bed = beds[row][col];
                String marker = bed.isOccupied() ? "[X]" : "[ ]";
                line.append(bed.getBedNumber()).append(marker).append("  ");
            }
            System.out.println(line.toString());
        }
        System.out.println("[ ] = Available    [X] = Occupied");
    }
}
