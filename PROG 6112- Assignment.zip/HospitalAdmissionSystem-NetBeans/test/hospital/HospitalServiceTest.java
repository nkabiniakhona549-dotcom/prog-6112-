package hospital;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * JUnit tests covering all functionality listed under
 * Feature 5: Unit Testing in the assignment brief.
 */
class HospitalServiceTest {

    private HospitalService service;

    @BeforeEach
    void setUp() {
        service = new HospitalService();
    }

    private Patient inpatient(String id, String surname) {
        return new Inpatient(id, "Test", surname, 30, "Male", "Flu", "Ward 1", "Not allocated");
    }

    private Patient outpatient(String id, String surname) {
        return new Patient(id, "Test", surname, 25, "Female", "Checkup", PatientCategory.OUTPATIENT);
    }

    // ---------- Register a patient ----------

    @Test
    void testRegisterPatient() throws DuplicatePatientException {
        Patient p = inpatient("P001", "Zulu");
        service.registerPatient(p);
        assertEquals(1, service.getAllPatients().size());
        assertEquals("P001", service.getAllPatients().get(0).getPatientId());
    }

    // ---------- Prevent duplicate Patient IDs ----------

    @Test
    void testPreventDuplicatePatientIds() throws DuplicatePatientException {
        service.registerPatient(inpatient("P001", "Zulu"));
        assertThrows(DuplicatePatientException.class,
                () -> service.registerPatient(inpatient("P001", "Ndlovu")));
    }

    // ---------- Search for a patient ----------

    @Test
    void testSearchForPatient() throws DuplicatePatientException, PatientNotFoundException {
        service.registerPatient(inpatient("P001", "Zulu"));
        Patient found = service.searchPatient("P001");
        assertEquals("Zulu", found.getLastName());
    }

    @Test
    void testSearchForNonExistentPatientThrows() {
        assertThrows(PatientNotFoundException.class, () -> service.searchPatient("P999"));
    }

    // ---------- Update patient details ----------

    @Test
    void testUpdatePatientDetails() throws DuplicatePatientException, PatientNotFoundException {
        service.registerPatient(outpatient("P002", "Khumalo"));
        service.updatePatient("P002", "Sipho", "Khumalo", 40, "Male", "Hypertension");

        Patient updated = service.searchPatient("P002");
        assertEquals("Sipho", updated.getFirstName());
        assertEquals(40, updated.getAge());
        assertEquals("Hypertension", updated.getMedicalCondition());
    }

    // ---------- Delete a patient ----------

    @Test
    void testDeletePatient() throws DuplicatePatientException, PatientNotFoundException {
        service.registerPatient(outpatient("P003", "Naidoo"));
        service.deletePatient("P003");
        assertEquals(0, service.getAllPatients().size());
        assertThrows(PatientNotFoundException.class, () -> service.searchPatient("P003"));
    }

    @Test
    void testDeleteReleasesBedIfOccupied() throws Exception {
        service.registerPatient(inpatient("P004", "Botha"));
        Bed bed = service.allocateBed("P004");

        service.deletePatient("P004");

        assertFalse(bed.isOccupied());
        assertNull(bed.getPatientId());
    }

    // ---------- Allocate a bed ----------

    @Test
    void testAllocateBed() throws Exception {
        service.registerPatient(inpatient("P005", "Van Wyk"));
        Bed bed = service.allocateBed("P005");

        assertNotNull(bed);
        assertTrue(bed.isOccupied());
        assertEquals("P005", bed.getPatientId());
    }

    @Test
    void testOnlyInpatientsCanBeAllocatedABed() throws DuplicatePatientException {
        service.registerPatient(outpatient("P006", "Smith"));
        assertThrows(BedNotAvailableException.class, () -> service.allocateBed("P006"));
    }

    // ---------- Release a bed ----------

    @Test
    void testReleaseBed() throws Exception {
        service.registerPatient(inpatient("P007", "Dlamini"));
        Bed bed = service.allocateBed("P007");

        service.releaseBed(bed.getBedNumber());

        assertFalse(bed.isOccupied());
        assertNull(bed.getPatientId());
    }

    @Test
    void testReleaseAlreadyAvailableBedThrows() {
        assertThrows(BedNotAvailableException.class, () -> service.releaseBed("B01"));
    }

    // ---------- Prevent allocating an occupied bed ----------

    @Test
    void testPreventAllocatingSamePatientTwice() throws Exception {
        service.registerPatient(inpatient("P008", "Mokoena"));
        service.allocateBed("P008");

        assertThrows(BedNotAvailableException.class, () -> service.allocateBed("P008"));
    }

    // ---------- Prevent bed allocation when all beds are occupied ----------

    @Test
    void testPreventBedAllocationWhenWardFull() throws Exception {
        // Fill all 20 beds.
        for (int i = 1; i <= Ward.TOTAL_BEDS; i++) {
            String id = "P" + String.format("%03d", i);
            service.registerPatient(inpatient(id, "Surname" + i));
            service.allocateBed(id);
        }

        // The 21st inpatient should not be able to get a bed.
        service.registerPatient(inpatient("P021", "Overflow"));
        assertThrows(BedNotAvailableException.class, () -> service.allocateBed("P021"));
        assertFalse(service.getWard().hasAvailableBed());
    }

    // ---------- Input validation / defensive checks ----------

    @Test
    void testRegisterPatientWithBlankIdThrows() {
        Patient p = outpatient("   ", "NoId");
        assertThrows(IllegalArgumentException.class, () -> service.registerPatient(p));
    }

    @Test
    void testNegativeAgeIsRejectedOnConstruction() {
        assertThrows(IllegalArgumentException.class,
                () -> new Patient("P040", "Bad", "Age", -5, "Male", "N/A", PatientCategory.OUTPATIENT));
    }

    @Test
    void testNegativeAgeIsRejectedOnUpdate() throws DuplicatePatientException, PatientNotFoundException {
        service.registerPatient(outpatient("P041", "Fine"));
        assertThrows(IllegalArgumentException.class,
                () -> service.updatePatient("P041", "Fine", "Fine", -1, "Male", "N/A"));
    }

    @Test
    void testInpatientCategoryMustUseInpatientClass() {
        // A base Patient object incorrectly marked as INPATIENT must be rejected,
        // since it has no ward/bed fields to store an allocation in.
        Patient invalid = new Patient("P042", "Mismatch", "Case", 20, "Male", "N/A", PatientCategory.INPATIENT);
        assertThrows(IllegalArgumentException.class, () -> service.registerPatient(invalid));
    }

    @Test
    void testReleasedInpatientBedNumberResetsToNotAllocated() throws Exception {
        Inpatient p = (Inpatient) inpatient("P043", "Reset");
        service.registerPatient(p);
        Bed bed = service.allocateBed("P043");

        service.releaseBed(bed.getBedNumber());

        assertEquals("Not allocated", p.getBedNumber());
    }

    // ---------- Sort patients by surname or Patient ID ----------

    @Test
    void testSortPatientsBySurname() throws DuplicatePatientException {
        service.registerPatient(outpatient("P010", "Zulu"));
        service.registerPatient(outpatient("P011", "Adams"));
        service.registerPatient(outpatient("P012", "Mokoena"));

        service.sortPatientsBySurname();

        assertEquals("Adams", service.getAllPatients().get(0).getLastName());
        assertEquals("Mokoena", service.getAllPatients().get(1).getLastName());
        assertEquals("Zulu", service.getAllPatients().get(2).getLastName());
    }

    @Test
    void testSortPatientsById() throws DuplicatePatientException {
        service.registerPatient(outpatient("P030", "Zulu"));
        service.registerPatient(outpatient("P011", "Adams"));
        service.registerPatient(outpatient("P020", "Mokoena"));

        service.sortPatientsById();

        assertEquals("P011", service.getAllPatients().get(0).getPatientId());
        assertEquals("P020", service.getAllPatients().get(1).getPatientId());
        assertEquals("P030", service.getAllPatients().get(2).getPatientId());
    }
}
