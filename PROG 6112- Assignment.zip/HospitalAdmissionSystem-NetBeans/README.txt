MediCare Hospital Patient Admission System - NetBeans Project
================================================================

HOW TO OPEN
------------
1. Unzip this folder anywhere on your computer.
2. Open NetBeans.
3. File -> Open Project... -> select the "HospitalAdmissionSystem-NetBeans" folder.
4. NetBeans will recognise it as a Java Application project and generate
   the internal build files automatically the first time you open/build it.

HOW TO RUN THE PROGRAM
------------------------
- Right-click the project in the Projects panel -> Run.
- This runs hospital.Main, which starts the console menu.

HOW TO RUN THE UNIT TESTS
----------------------------
NetBeans does not download JUnit from the internet the way Maven does, so
you need to add the JUnit library to the project once (takes 10 seconds):

1. Right-click the project -> Properties.
2. Go to Libraries -> Test Libraries tab.
3. Click "Add Library..." and choose "JUnit 5" (or "JUnit" if that is the
   only version listed) from the list NetBeans ships with, then OK.
4. Click OK to close Properties.
5. Right-click HospitalServiceTest.java (inside the "Test Packages" node,
   package hospital) -> Test File (or press Alt+F6 with it open).

All 15+ test cases should pass, covering:
 - Registering a patient / preventing duplicate Patient IDs
 - Searching for a patient
 - Updating patient details
 - Deleting a patient (and releasing their bed automatically)
 - Allocating and releasing a bed
 - Preventing bed allocation for non-Inpatients
 - Preventing allocation of an already-occupied bed
 - Preventing allocation when the ward is full
 - Sorting patients by surname and by Patient ID

PROJECT STRUCTURE
--------------------
src/hospital/            - main source files (Patient, Inpatient, Ward, Bed,
                            HospitalService, Main, custom exceptions, enum)
test/hospital/           - JUnit 5 test class (HospitalServiceTest.java)
nbproject/                - NetBeans project configuration
build.xml                 - Ant build script (standard NetBeans wrapper)
manifest.mf                - Manifest used when NetBeans builds the JAR

NOTE
------
If you would rather use Maven (e.g. in IntelliJ or Eclipse), a separate
Maven-based version of this same project with a pom.xml is available -
just ask for it.
